"""
Sensitive Data Detection & Compliance Assistant
------------------------------------------------
Streamlit front-end. Wires together: parser -> detectors -> risk ->
summarizer -> qa -> masking -> audit.

Run:
    streamlit run app.py
"""

import os
import io
import pandas as pd
import streamlit as st

from modules import parser, detectors, risk, summarizer, qa, masking, audit

st.set_page_config(
    page_title="Sensitive Data Detection & Compliance Assistant",
    page_icon="🛡️",
    layout="wide",
)

# --------------------------------------------------------------------------
# Session state init
# --------------------------------------------------------------------------
for key, default in {
    "doc_text": None,
    "doc_df": None,
    "filename": None,
    "findings": None,
    "risk_result": None,
    "summary_result": None,
    "chat_history": [],
    "redacted_text": None,
}.items():
    if key not in st.session_state:
        st.session_state[key] = default


# --------------------------------------------------------------------------
# Sidebar: config
# --------------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ Configuration")
    api_key = st.text_input(
        "Anthropic API Key (optional)",
        type="password",
        help="Used only for the narrative AI summary and free-form Q&A. "
             "Only aggregated category counts (never raw sensitive values) "
             "are sent for the summary. Leave blank to use the fully "
             "offline rule-based mode.",
        value=os.environ.get("ANTHROPIC_API_KEY", ""),
    )
    model = st.selectbox(
        "Model",
        ["claude-sonnet-4-6", "claude-opus-4-1", "claude-haiku-4-5"],
        index=0,
    )
    use_redacted_context = st.checkbox(
        "Send redacted text to LLM for Q&A (recommended)",
        value=True,
        help="When enabled, free-form Q&A sends a masked version of the "
             "document to the LLM instead of raw sensitive values.",
    )

    st.divider()
    st.header("📜 Audit Log")
    if st.button("Show recent scans"):
        log_entries = audit.read_log()
        if log_entries:
            st.dataframe(pd.DataFrame(log_entries), use_container_width=True)
        else:
            st.caption("No scans logged yet.")

    st.divider()
    st.caption(
        "This app detects patterns that *look like* sensitive data using "
        "regex heuristics. It is a decision-support tool, not a legal "
        "compliance guarantee — always have a human review High risk "
        "findings before acting."
    )


# --------------------------------------------------------------------------
# Header
# --------------------------------------------------------------------------
st.title("🛡️ Sensitive Data Detection & Compliance Assistant")
st.caption(
    "Upload a PDF, TXT, or CSV document to detect sensitive information, "
    "classify risk, generate a compliance summary, and ask questions."
)

uploaded_file = st.file_uploader(
    "Upload a document", type=["pdf", "txt", "csv"],
    help="Supported formats: PDF, TXT, CSV",
)

col_a, col_b = st.columns([1, 1])
with col_a:
    scan_clicked = st.button("🔍 Scan Document", type="primary", disabled=uploaded_file is None)
with col_b:
    if st.button("🗑️ Clear session"):
        for key in list(st.session_state.keys()):
            st.session_state[key] = None if key != "chat_history" else []
        st.rerun()


# --------------------------------------------------------------------------
# Scan pipeline
# --------------------------------------------------------------------------
if scan_clicked and uploaded_file is not None:
    with st.spinner("Parsing document..."):
        file_bytes = uploaded_file.read()
        try:
            text, df = parser.parse_document(uploaded_file.name, file_bytes)
        except Exception as e:
            st.error(f"Failed to parse document: {e}")
            st.stop()

    with st.spinner("Detecting sensitive data..."):
        findings = detectors.detect_all(text)

    with st.spinner("Classifying risk..."):
        risk_result = risk.classify(findings)

    st.session_state.doc_text = text
    st.session_state.doc_df = df
    st.session_state.filename = uploaded_file.name
    st.session_state.findings = findings
    st.session_state.risk_result = risk_result
    st.session_state.redacted_text = masking.redact_text(text, findings)
    st.session_state.summary_result = None  # reset, generated lazily in its tab
    st.session_state.chat_history = []

    findings_summary = detectors.summarize_counts(findings)
    audit.log_scan(uploaded_file.name, risk_result, findings_summary)
    st.success(f"Scan complete: {uploaded_file.name}")


# --------------------------------------------------------------------------
# Results
# --------------------------------------------------------------------------
if st.session_state.doc_text is not None:
    text = st.session_state.doc_text
    findings = st.session_state.findings
    risk_result = st.session_state.risk_result

    tabs = st.tabs([
        "📊 Overview", "🔎 Detected Data", "📝 Compliance Summary",
        "🕶️ Redacted View", "💬 Ask Questions",
    ])

    # ---- Overview -----------------------------------------------------
    with tabs[0]:
        c1, c2, c3, c4 = st.columns(4)
        total_findings = sum(len(v) for v in findings.values())
        c1.metric("File", st.session_state.filename)
        c2.metric("Total sensitive items", total_findings)
        c3.metric("Risk score", risk_result["total_score"])
        color = risk.risk_color(risk_result["risk_level"])
        c4.markdown(
            f"<div style='text-align:center'><span style='font-size:14px;color:gray'>Risk level</span><br>"
            f"<span style='font-size:28px;font-weight:700;color:{color}'>{risk_result['risk_level']}</span></div>",
            unsafe_allow_html=True,
        )

        st.subheader("Category breakdown")
        if risk_result["breakdown"]:
            bd = pd.DataFrame(risk_result["breakdown"])
            bd = bd[bd["count"] > 0][["label", "count", "weight", "score", "auto_high"]]
            bd.columns = ["Category", "Count", "Severity Weight", "Contribution Score", "Critical (auto-High)"]
            st.dataframe(bd, use_container_width=True, hide_index=True)
            st.bar_chart(bd.set_index("Category")["Count"])
        else:
            st.info("No sensitive data detected in this document.")

        if st.session_state.doc_df is not None:
            with st.expander("Preview parsed CSV"):
                st.dataframe(st.session_state.doc_df.head(20), use_container_width=True)

    # ---- Detected Data --------------------------------------------------
    with tabs[1]:
        st.subheader("All detected items")
        flat = detectors.flatten(findings)
        if not flat:
            st.info("Nothing detected.")
        else:
            filter_cats = st.multiselect(
                "Filter by category", sorted(findings.keys()),
                default=sorted(findings.keys()),
            )
            rows = [
                {
                    "Category": item["type"],
                    "Value (as detected)": item["value"],
                    "Confidence": item["confidence"],
                    "Context": item["context"],
                }
                for item in flat if item["type"] in filter_cats
            ]
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
            st.caption(
                "⚠️ Raw values are shown here for review purposes. Use the "
                "Redacted View tab before sharing this document externally."
            )

    # ---- Compliance Summary --------------------------------------------
    with tabs[2]:
        st.subheader("AI-generated compliance & security summary")
        gen_col, mode_col = st.columns([1, 3])
        with gen_col:
            generate = st.button("Generate / Regenerate Summary")
        if generate or st.session_state.summary_result is None:
            with st.spinner("Generating summary..."):
                doc_stats = {
                    "filename": st.session_state.filename,
                    "characters": len(text),
                    "total_sensitive_items": sum(len(v) for v in findings.values()),
                }
                st.session_state.summary_result = summarizer.generate_summary(
                    findings, risk_result, doc_stats,
                    api_key=api_key or None, model=model,
                )
        result = st.session_state.summary_result
        with mode_col:
            badge = "🤖 AI-generated (Claude)" if result["mode"] == "llm" else "📐 Rule-based (offline)"
            st.caption(badge)
        if result.get("error"):
            st.warning(result["error"])
        st.markdown(result["summary"])

    # ---- Redacted View ---------------------------------------------------
    with tabs[3]:
        st.subheader("Redacted document preview")
        st.text_area("Redacted text", st.session_state.redacted_text, height=400)
        st.download_button(
            "⬇️ Download redacted text",
            data=st.session_state.redacted_text,
            file_name=f"redacted_{st.session_state.filename}.txt",
            mime="text/plain",
        )

    # ---- Ask Questions -----------------------------------------------------
    with tabs[4]:
        st.subheader("Ask questions about this document")
        st.caption(
            "Try: “What sensitive data exists in this document?”, "
            "“How many email addresses are present?”, "
            "“Summarize this document.”, "
            "“What compliance risks are identified?”"
        )

        for role, msg in st.session_state.chat_history:
            with st.chat_message(role):
                st.markdown(msg)

        question = st.chat_input("Ask a question about the uploaded document...")
        if question:
            st.session_state.chat_history.append(("user", question))
            with st.chat_message("user"):
                st.markdown(question)

            with st.chat_message("assistant"):
                with st.spinner("Thinking..."):
                    qa_result = qa.answer_question(
                        question, text, findings, risk_result,
                        api_key=api_key or None, model=model,
                        use_redacted_context=use_redacted_context,
                        redacted_text=st.session_state.redacted_text,
                    )
                    answer = qa_result["answer"]
                    if answer == "__DELEGATE_TO_SUMMARY__":
                        if st.session_state.summary_result is None:
                            doc_stats = {
                                "filename": st.session_state.filename,
                                "characters": len(text),
                                "total_sensitive_items": sum(len(v) for v in findings.values()),
                            }
                            st.session_state.summary_result = summarizer.generate_summary(
                                findings, risk_result, doc_stats,
                                api_key=api_key or None, model=model,
                            )
                        answer = st.session_state.summary_result["summary"]
                st.markdown(answer)
            st.session_state.chat_history.append(("assistant", answer))

else:
    st.info("👆 Upload a document and click **Scan Document** to get started.")
    with st.expander("Try it with sample data"):
        st.markdown(
            "A sample file with synthetic (fake) sensitive data is included at "
            "`sample_data/sample.txt` in the repository — upload it here to see "
            "the app in action without using any real personal data."
        )
