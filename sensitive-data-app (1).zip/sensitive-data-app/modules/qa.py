"""
qa.py
-----
Question answering over the uploaded document.

Two layers, checked in order:
  1. Intent matching for common structured questions ("how many emails",
     "what sensitive data exists", "summarize this document",
     "what compliance risks are identified") - answered directly and
     deterministically from the detector/risk output, no LLM needed.
  2. Free-form fallback: if no intent matches and an API key is
     available, the question + document text (optionally redacted) is
     sent to Claude for a grounded answer (simple single-document RAG:
     the whole doc is used as context since these documents are
     typically short; for very long documents the text is chunked and
     the most relevant chunks are selected by keyword overlap before
     being sent, to keep within context limits - see `_select_chunks`).
"""

import os
import re
from typing import Dict, List, Optional

from modules import detectors as det_module


CATEGORY_ALIASES = {
    "email": "EMAIL", "emails": "EMAIL", "e-mail": "EMAIL",
    "phone": "PHONE", "phones": "PHONE", "mobile": "PHONE", "contact number": "PHONE",
    "pan": "PAN",
    "aadhaar": "AADHAAR", "aadhar": "AADHAAR",
    "credit card": "CREDIT_CARD", "card": "CREDIT_CARD", "cards": "CREDIT_CARD",
    "bank account": "BANK_ACCOUNT", "bank details": "BANK_ACCOUNT", "account number": "BANK_ACCOUNT",
    "ifsc": "IFSC",
    "api key": "GENERIC_API_KEY", "api keys": "GENERIC_API_KEY", "aws key": "AWS_KEY",
    "password": "PASSWORD_ASSIGNMENT", "passwords": "PASSWORD_ASSIGNMENT", "secret": "PASSWORD_ASSIGNMENT",
    "employee id": "EMPLOYEE_ID", "employee ids": "EMPLOYEE_ID",
    "ip address": "IP_ADDRESS", "ip addresses": "IP_ADDRESS",
    "confidential": "CONFIDENTIAL_MARKER",
}


def _match_category(question: str) -> Optional[str]:
    q = question.lower()
    for alias, category in CATEGORY_ALIASES.items():
        if alias in q:
            return category
    return None


def _answer_count_question(question: str, findings: Dict) -> Optional[str]:
    if not re.search(r"\bhow many\b|\bnumber of\b|\bcount\b", question.lower()):
        return None
    category = _match_category(question)
    if category:
        count = len(findings.get(category, []))
        label = det_module.CONFIDENTIAL_KEYWORDS if False else category
        return f"There are **{count}** occurrence(s) of {category.replace('_', ' ').title()} in this document."
    total = sum(len(v) for v in findings.values())
    return f"There are **{total}** total sensitive-data occurrence(s) detected across all categories."


def _answer_what_exists_question(question: str, findings: Dict) -> Optional[str]:
    ql = question.lower()
    if not any(p in ql for p in ["what sensitive", "what kind of", "what types", "which sensitive",
                                  "what data exists", "list the sensitive"]):
        return None
    if not findings:
        return "No sensitive data categories were detected in this document."
    lines = ["The following sensitive-data categories were detected:"]
    for cat, items in sorted(findings.items(), key=lambda x: -len(x[1])):
        lines.append(f"- **{cat.replace('_', ' ').title()}**: {len(items)} occurrence(s)")
    return "\n".join(lines)


def _answer_compliance_question(question: str, risk_result: Dict) -> Optional[str]:
    ql = question.lower()
    if not any(p in ql for p in ["compliance risk", "compliance issue", "regulatory", "what risks"]):
        return None
    lvl = risk_result["risk_level"]
    cats = [b["label"] for b in risk_result["breakdown"] if b["count"] > 0]
    if not cats:
        return f"Overall risk level is **{lvl}**. No specific sensitive-data categories were found to drive compliance risk."
    return (f"Overall risk level is **{lvl}** (score: {risk_result['total_score']}). "
            f"Key contributing categories: {', '.join(cats)}. "
            "See the Compliance Summary tab for detailed observations and remediation steps.")


def _answer_summarize_question(question: str) -> Optional[str]:
    ql = question.lower()
    if "summarize" in ql or "summary" in ql:
        return "__DELEGATE_TO_SUMMARY__"
    return None


def _select_chunks(text: str, question: str, chunk_size: int = 1200, max_chunks: int = 4) -> str:
    """Very lightweight keyword-overlap chunk selection for longer documents."""
    if len(text) <= chunk_size * max_chunks:
        return text
    words = set(re.findall(r"\w+", question.lower()))
    chunks = [text[i:i + chunk_size] for i in range(0, len(text), chunk_size)]
    scored = []
    for c in chunks:
        c_words = set(re.findall(r"\w+", c.lower()))
        overlap = len(words & c_words)
        scored.append((overlap, c))
    scored.sort(key=lambda x: x[0], reverse=True)
    top = [c for _, c in scored[:max_chunks]]
    return "\n...\n".join(top)


def _call_llm(api_key: str, model: str, question: str, context_text: str) -> str:
    import anthropic
    client = anthropic.Anthropic(api_key=api_key)
    system = ("You are a document assistant. Answer the user's question strictly using the "
               "provided document excerpt. If the answer isn't in the excerpt, say so. Be concise.")
    prompt = f"Document excerpt:\n---\n{context_text}\n---\n\nQuestion: {question}"
    response = client.messages.create(
        model=model, max_tokens=600, system=system,
        messages=[{"role": "user", "content": prompt}],
    )
    parts = [b.text for b in response.content if getattr(b, "type", "") == "text"]
    return "\n".join(parts).strip()


def answer_question(question: str, text: str, findings: Dict, risk_result: Dict,
                     api_key: str = None, model: str = "claude-sonnet-4-6",
                     use_redacted_context: bool = True, redacted_text: str = None) -> Dict:
    """Returns {"answer": str, "mode": "rule_based"|"llm", "error": str|None}"""

    for fn, args in [
        (_answer_count_question, (question, findings)),
        (_answer_what_exists_question, (question, findings)),
        (_answer_compliance_question, (question, risk_result)),
        (_answer_summarize_question, (question,)),
    ]:
        result = fn(*args)
        if result and result != "__DELEGATE_TO_SUMMARY__":
            return {"answer": result, "mode": "rule_based", "error": None}
        if result == "__DELEGATE_TO_SUMMARY__":
            return {"answer": "__DELEGATE_TO_SUMMARY__", "mode": "rule_based", "error": None}

    api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return {
            "answer": ("I can answer structured questions (counts, category lists, compliance "
                       "risk) without an API key. For open-ended questions, add an Anthropic API "
                       "key in the sidebar to enable free-form Q&A."),
            "mode": "rule_based", "error": None,
        }

    context_source = redacted_text if (use_redacted_context and redacted_text) else text
    context_text = _select_chunks(context_source, question)
    try:
        answer = _call_llm(api_key, model, question, context_text)
        return {"answer": answer, "mode": "llm", "error": None}
    except Exception as e:
        return {"answer": f"Couldn't reach the LLM ({e}). Try a structured question instead, "
                           f"e.g. 'how many emails are present?'", "mode": "rule_based", "error": str(e)}
