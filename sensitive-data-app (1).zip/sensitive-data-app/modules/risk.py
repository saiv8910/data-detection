"""
risk.py
-------
Turns the raw detector findings into a risk score + Low/Medium/High
classification, plus a human-readable breakdown that feeds both the
UI and the AI summary prompt.

Scoring approach (transparent, rule-based - easy to audit/tune):
  * Each category has a base "severity weight".
  * Score = sum(weight * count) for all categories, with a soft cap
    per category (extra occurrences add diminishing returns) so one
    category with a lot of hits can't single-handedly blow the scale.
  * A category marked `auto_high` present even once forces the
    document to at least High risk (e.g. Aadhaar, credit card, API
    keys/passwords - these are severe regardless of volume).
"""

from typing import Dict, List, Tuple
import math

# severity weight per detected instance, and whether a single hit
# should force the document into the High bucket
CATEGORY_CONFIG = {
    "AADHAAR":             {"weight": 10, "auto_high": True,  "label": "Aadhaar Number"},
    "CREDIT_CARD":         {"weight": 10, "auto_high": True,  "label": "Credit Card Number"},
    "AWS_KEY":             {"weight": 10, "auto_high": True,  "label": "AWS Access Key"},
    "GENERIC_API_KEY":     {"weight": 9,  "auto_high": True,  "label": "API Key"},
    "PASSWORD_ASSIGNMENT": {"weight": 9,  "auto_high": True,  "label": "Password / Secret"},
    "PAN":                 {"weight": 7,  "auto_high": False, "label": "PAN Number"},
    "BANK_ACCOUNT":        {"weight": 7,  "auto_high": False, "label": "Bank Account Number"},
    "IFSC":                {"weight": 4,  "auto_high": False, "label": "IFSC Code"},
    "EMPLOYEE_ID":         {"weight": 3,  "auto_high": False, "label": "Employee ID"},
    "PHONE":               {"weight": 3,  "auto_high": False, "label": "Phone Number"},
    "EMAIL":               {"weight": 2,  "auto_high": False, "label": "Email Address"},
    "IP_ADDRESS":          {"weight": 2,  "auto_high": False, "label": "IP Address"},
    "CONFIDENTIAL_MARKER": {"weight": 5,  "auto_high": False, "label": "Confidential Business Marker"},
}

LOW_THRESHOLD = 10      # score below this -> Low
HIGH_THRESHOLD = 30     # score at/above this -> High (Medium in between)


def _category_score(weight: int, count: int) -> float:
    """Diminishing returns: weight * (1 + log2(count)) instead of weight*count."""
    if count <= 0:
        return 0.0
    return weight * (1 + math.log2(count))


def classify(findings: Dict[str, List[Dict]]) -> Dict:
    breakdown = []
    total_score = 0.0
    forced_high = False

    for category, items in findings.items():
        cfg = CATEGORY_CONFIG.get(category)
        if not cfg:
            continue
        count = len(items)
        score = _category_score(cfg["weight"], count)
        total_score += score
        if cfg["auto_high"] and count > 0:
            forced_high = True
        breakdown.append({
            "category": category,
            "label": cfg["label"],
            "count": count,
            "weight": cfg["weight"],
            "score": round(score, 1),
            "auto_high": cfg["auto_high"],
        })

    breakdown.sort(key=lambda x: x["score"], reverse=True)

    if forced_high or total_score >= HIGH_THRESHOLD:
        risk_level = "High"
    elif total_score >= LOW_THRESHOLD:
        risk_level = "Medium"
    else:
        risk_level = "Low" if total_score > 0 else "Low"

    return {
        "risk_level": risk_level,
        "total_score": round(total_score, 1),
        "forced_high": forced_high,
        "breakdown": breakdown,
        "thresholds": {"low_max": LOW_THRESHOLD, "high_min": HIGH_THRESHOLD},
    }


def risk_color(risk_level: str) -> str:
    return {"Low": "#2e7d32", "Medium": "#f9a825", "High": "#c62828"}.get(risk_level, "#555")
