"""
detectors.py
------------
Regex + heuristic based sensitive data detectors.

Each detector returns a list of dicts:
    {
        "type": "PAN",
        "value": "ABCDE1234F",
        "start": 120,
        "end": 130,
        "context": "...surrounding text...",
        "confidence": "high" | "medium" | "low"
    }

No third-party NLP model is required to run this file; it is pure
regex + light validation (Luhn / IFSC bank code list / keyword proximity)
so the app works fully offline for the detection stage. The optional
AI layer (modules/summarizer.py, modules/qa.py) is only used for the
narrative summary and the chat Q&A on top of these findings.
"""

import re
from dataclasses import dataclass, field
from typing import List, Dict


# --------------------------------------------------------------------------
# Helper validators
# --------------------------------------------------------------------------

def _luhn_valid(number: str) -> bool:
    """Validate a credit-card-like number using the Luhn checksum."""
    digits = [int(d) for d in number if d.isdigit()]
    if len(digits) < 13 or len(digits) > 19:
        return False
    checksum = 0
    parity = len(digits) % 2
    for i, d in enumerate(digits):
        if i % 2 == parity:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0


def _context_window(text: str, start: int, end: int, radius: int = 40) -> str:
    lo = max(0, start - radius)
    hi = min(len(text), end + radius)
    snippet = text[lo:hi].replace("\n", " ")
    return snippet.strip()


def _has_nearby_keyword(text: str, start: int, end: int, keywords, radius: int = 45) -> bool:
    lo = max(0, start - radius)
    hi = min(len(text), end + radius)
    window = text[lo:hi].lower()
    return any(k in window for k in keywords)


# --------------------------------------------------------------------------
# Individual detectors
# --------------------------------------------------------------------------

PATTERNS = {
    "EMAIL": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),

    # Indian mobile numbers, with or without +91 / 0 prefix, allowing spaces/hyphens
    "PHONE": re.compile(r"(?<!\d)(?:\+?91[\s-]?)?[6-9]\d{9}(?!\d)"),

    # PAN: 5 letters, 4 digits, 1 letter
    "PAN": re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b"),

    # Aadhaar: 12 digits, commonly grouped 4-4-4
    "AADHAAR": re.compile(r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}\b"),

    # Generic card-like number: 13-19 digits, grouped in 4s or continuous
    "CREDIT_CARD": re.compile(r"\b(?:\d[ -]?){13,19}\b"),

    # IFSC code: 4 letters, 0, 6 alphanumeric
    "IFSC": re.compile(r"\b[A-Z]{4}0[A-Z0-9]{6}\b"),

    # Bank account numbers are just long digit runs - only flagged with context keyword
    "BANK_ACCOUNT": re.compile(r"\b\d{9,18}\b"),

    # Common cloud / API secret formats
    "AWS_KEY": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "GENERIC_API_KEY": re.compile(
        r"\b(?:sk|pk|rk)-[A-Za-z0-9_-]{20,}\b|"          # Stripe/OpenAI-style keys
        r"\b(?:key|api)[_-][A-Za-z0-9]{16,}\b|"           # generic key_xxx / api_xxx
        r"\bAIza[0-9A-Za-z\-_]{35}\b|"                    # Google API key
        r"\bghp_[A-Za-z0-9]{36}\b"                        # GitHub PAT
    ),
    "PASSWORD_ASSIGNMENT": re.compile(
        r"(?:password|passwd|pwd|secret|token)\s*[:=]\s*[^\s,;]{4,}", re.IGNORECASE
    ),

    # Employee IDs - alphanumeric codes near the word "employee"/"emp id" etc.
    "EMPLOYEE_ID": re.compile(r"\b(?:EMP|Emp|emp)[-_ ]?\d{3,8}\b"),

    # IP addresses (useful for infra / security review)
    "IP_ADDRESS": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
}

CONFIDENTIAL_KEYWORDS = [
    "confidential", "internal use only", "do not distribute", "trade secret",
    "proprietary", "strictly private", "not for distribution", "classified",
    "nda", "non-disclosure", "restricted access",
]

BANK_CONTEXT_KEYWORDS = [
    "account no", "account number", "acc no", "a/c", "bank account", "iban",
    "routing number", "swift", "ifsc",
]

EMPLOYEE_CONTEXT_KEYWORDS = ["employee", "emp id", "staff id", "personnel"]


def detect_all(text: str) -> Dict[str, List[Dict]]:
    """Run every detector over `text` and return findings grouped by type."""
    findings: Dict[str, List[Dict]] = {}

    # --- straightforward pattern-only categories -------------------------
    for label in ["EMAIL", "PAN", "IFSC", "AWS_KEY", "GENERIC_API_KEY",
                  "PASSWORD_ASSIGNMENT", "EMPLOYEE_ID", "IP_ADDRESS"]:
        matches = []
        for m in PATTERNS[label].finditer(text):
            matches.append({
                "type": label,
                "value": m.group(),
                "start": m.start(),
                "end": m.end(),
                "context": _context_window(text, m.start(), m.end()),
                "confidence": "high",
            })
        if matches:
            findings[label] = matches

    # --- phone: validate it isn't actually part of a longer digit run ----
    phone_matches = []
    for m in PATTERNS["PHONE"].finditer(text):
        phone_matches.append({
            "type": "PHONE",
            "value": m.group(),
            "start": m.start(),
            "end": m.end(),
            "context": _context_window(text, m.start(), m.end()),
            "confidence": "high",
        })
    if phone_matches:
        findings["PHONE"] = phone_matches

    # --- Aadhaar: 12-digit grouped numbers, avoid overlap with phone -----
    aadhaar_matches = []
    seen_spans = set()
    for m in PATTERNS["AADHAAR"].finditer(text):
        digits_only = re.sub(r"[\s-]", "", m.group())
        if len(digits_only) != 12:
            continue
        if digits_only[0] in "01":  # Aadhaar never starts with 0/1
            continue
        span = (m.start(), m.end())
        if span in seen_spans:
            continue
        seen_spans.add(span)
        aadhaar_matches.append({
            "type": "AADHAAR",
            "value": m.group(),
            "start": m.start(),
            "end": m.end(),
            "context": _context_window(text, m.start(), m.end()),
            "confidence": "medium",  # format-only validation, no checksum
        })
    if aadhaar_matches:
        findings["AADHAAR"] = aadhaar_matches

    # --- Credit card: Luhn-validated ---------------------------------------
    cc_matches = []
    for m in PATTERNS["CREDIT_CARD"].finditer(text):
        candidate = m.group()
        if _luhn_valid(candidate):
            cc_matches.append({
                "type": "CREDIT_CARD",
                "value": candidate,
                "start": m.start(),
                "end": m.end(),
                "context": _context_window(text, m.start(), m.end()),
                "confidence": "high",
            })
    if cc_matches:
        findings["CREDIT_CARD"] = cc_matches

    # --- Bank account numbers: digit run + nearby keyword -----------------
    bank_matches = []
    for m in PATTERNS["BANK_ACCOUNT"].finditer(text):
        if _has_nearby_keyword(text, m.start(), m.end(), BANK_CONTEXT_KEYWORDS):
            # avoid double counting numbers already flagged as credit card / aadhaar / phone
            overlap = any(
                m.start() < f["end"] and m.end() > f["start"]
                for cat in ("CREDIT_CARD", "AADHAAR", "PHONE")
                for f in findings.get(cat, [])
            )
            if not overlap:
                bank_matches.append({
                    "type": "BANK_ACCOUNT",
                    "value": m.group(),
                    "start": m.start(),
                    "end": m.end(),
                    "context": _context_window(text, m.start(), m.end()),
                    "confidence": "medium",
                })
    if bank_matches:
        findings["BANK_ACCOUNT"] = bank_matches

    # --- Confidential business info: keyword spotting ----------------------
    conf_matches = []
    lowered = text.lower()
    for kw in CONFIDENTIAL_KEYWORDS:
        for m in re.finditer(re.escape(kw), lowered):
            conf_matches.append({
                "type": "CONFIDENTIAL_MARKER",
                "value": text[m.start():m.end()],
                "start": m.start(),
                "end": m.end(),
                "context": _context_window(text, m.start(), m.end()),
                "confidence": "medium",
            })
    if conf_matches:
        findings["CONFIDENTIAL_MARKER"] = conf_matches

    return findings


def flatten(findings: Dict[str, List[Dict]]) -> List[Dict]:
    """Flatten the grouped findings dict into a single list, sorted by position."""
    flat = [item for group in findings.values() for item in group]
    flat.sort(key=lambda x: x["start"])
    return flat


def summarize_counts(findings: Dict[str, List[Dict]]) -> Dict[str, int]:
    return {label: len(items) for label, items in findings.items()}
