"""
masking.py
----------
Produces a redacted copy of the document text, replacing each detected
sensitive value with a masked placeholder. Useful for sharing a
document safely or for a "before/after" compliance demonstration.
"""

from typing import Dict, List


def _mask_value(value: str, category: str) -> str:
    """Keep a small hint of the value (last 2-4 chars) for usability, mask the rest."""
    if category == "EMAIL":
        local, _, domain = value.partition("@")
        visible = local[:2]
        return f"{visible}{'*' * max(len(local) - 2, 2)}@{domain}"
    if category in ("PHONE",):
        return "*" * (len(value) - 2) + value[-2:]
    if category in ("AADHAAR", "CREDIT_CARD", "BANK_ACCOUNT"):
        digits = value
        return "*" * max(len(digits) - 4, 0) + digits[-4:]
    if category == "PAN":
        return value[:2] + "***" + value[-2:]
    # default: fully mask, but show category tag
    return f"[REDACTED:{category}]"


def redact_text(text: str, findings: Dict[str, List[Dict]]) -> str:
    flat = [item for group in findings.values() for item in group]
    # sort by start descending so string slicing offsets don't shift
    flat.sort(key=lambda x: x["start"], reverse=True)

    redacted = text
    for item in flat:
        masked = _mask_value(item["value"], item["type"])
        redacted = redacted[:item["start"]] + masked + redacted[item["end"]:]
    return redacted
