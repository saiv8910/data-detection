"""
summarizer.py
-------------
Generates the compliance/security narrative summary.

Two modes:
  1. LLM mode (preferred): if an Anthropic API key is configured, the
     detector findings + risk breakdown are passed to Claude as
     structured context and Claude writes the narrative summary
     (compliance observations, security risks, remediation steps).
     The LLM never sees the raw document text with full sensitive
     values - only redacted/aggregated statistics - so no sensitive
     data is sent over the network for the summary step.
  2. Rule-based fallback (no API key required): builds the same three
     sections from templates driven by the risk breakdown, so the app
     is fully usable offline / without any API key.
"""

import os
from typing import Dict, List

SYSTEM_PROMPT = """You are a data privacy and information-security compliance assistant.
You will be given an aggregated, anonymized inventory of sensitive-data categories found
in a document (category names and counts only - never raw values) plus a computed risk
score. Write a concise professional compliance summary with exactly three sections:

1. Compliance Observations - what regulations/policies are implicated (e.g. India's
   DPDP Act, PCI-DSS for card data, internal confidentiality policy) and what was found.
2. Security Risks - concrete risks this exposure creates if the document were leaked
   or mishandled.
3. Suggested Remediation Steps - a short numbered list of practical next actions.

Keep it factual, avoid alarmism, and do not invent findings beyond what's given.
Use markdown with the three headings as ### headers."""


def _build_context_block(findings_summary: Dict, risk_result: Dict, doc_stats: Dict) -> str:
    lines = ["Document stats:"]
    for k, v in doc_stats.items():
        lines.append(f"- {k}: {v}")

    lines.append("\nDetected sensitive-data categories (counts only, no raw values):")
    if findings_summary:
        for cat, count in findings_summary.items():
            lines.append(f"- {cat}: {count} occurrence(s)")
    else:
        lines.append("- None detected")

    lines.append(f"\nComputed risk level: {risk_result['risk_level']}")
    lines.append(f"Computed risk score: {risk_result['total_score']}")
    if risk_result.get("forced_high"):
        lines.append("Note: risk was auto-escalated to High because a critical category "
                      "(Aadhaar, credit card, API key, or password) was present.")

    return "\n".join(lines)


def _call_claude(api_key: str, model: str, context_block: str) -> str:
    import anthropic

    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model=model,
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": context_block}],
    )
    parts = [block.text for block in response.content if getattr(block, "type", "") == "text"]
    return "\n".join(parts).strip()


def _rule_based_summary(findings_summary: Dict, risk_result: Dict, doc_stats: Dict) -> str:
    risk = risk_result["risk_level"]
    breakdown = risk_result["breakdown"]

    obs_lines = []
    if not findings_summary:
        obs_lines.append("No sensitive-data patterns were detected in this document based on "
                          "the current rule set.")
    else:
        for item in breakdown:
            if item["count"] == 0:
                continue
            obs_lines.append(f"- **{item['label']}**: {item['count']} occurrence(s) found. "
                              f"{'This is treated as a critical category regardless of volume.' if item['auto_high'] else ''}")
        if any(item["category"] in ("AADHAAR", "PAN") for item in breakdown):
            obs_lines.append("- Presence of government ID numbers (Aadhaar/PAN) brings this "
                              "document under India's Digital Personal Data Protection (DPDP) Act "
                              "2023 scope as it qualifies as personal data.")
        if any(item["category"] == "CREDIT_CARD" for item in breakdown):
            obs_lines.append("- Card numbers are in scope for PCI-DSS; storing them in plain "
                              "text documents is a direct compliance violation.")
        if any(item["category"] in ("AWS_KEY", "GENERIC_API_KEY", "PASSWORD_ASSIGNMENT") for item in breakdown):
            obs_lines.append("- Hard-coded credentials/secrets were found - this violates "
                              "standard secrets-management policy (e.g. OWASP, SOC 2 CC6.1).")

    sec_lines = {
        "Low": ["Limited exposure risk; primarily low-sensitivity identifiers such as emails "
                "or IP addresses.", "Risk of nuisance contact (spam/phishing) if leaked, but "
                "low likelihood of direct financial or identity harm."],
        "Medium": ["Exposure could enable targeted social engineering or identity-adjacent fraud.",
                   "Aggregated contact and identifier data increases re-identification risk "
                   "if combined with other leaked datasets."],
        "High": ["Exposure could directly enable identity theft, financial fraud, or "
                 "unauthorized system access (if credentials/API keys are present).",
                 "Regulatory and contractual penalties are likely if this document is leaked "
                 "or improperly shared.",
                 "Reputational damage and breach-notification obligations may be triggered."],
    }[risk]

    remediation = {
        "Low": ["Apply standard access controls and confirm the document isn't publicly shared.",
                "Periodically re-scan documents as content evolves."],
        "Medium": ["Restrict document access to a defined group on a need-to-know basis.",
                   "Mask or redact identifiers before wider distribution.",
                   "Add a data-handling classification label to the document."],
        "High": ["Immediately restrict access and move the document to an encrypted, "
                 "access-controlled location.",
                 "Rotate any exposed credentials/API keys without delay.",
                 "Redact or tokenize Aadhaar/PAN/card numbers before any further sharing.",
                 "Notify your data protection officer / compliance team per internal breach "
                 "response procedures.",
                 "Review who has previously accessed or downloaded this document."],
    }[risk]

    md = ["### Compliance Observations", *(obs_lines or ["No issues identified."]),
          "", "### Security Risks", *(f"- {s}" for s in sec_lines),
          "", "### Suggested Remediation Steps", *(f"{i+1}. {s}" for i, s in enumerate(remediation))]
    return "\n".join(md)


def generate_summary(findings: Dict, risk_result: Dict, doc_stats: Dict,
                      api_key: str = None, model: str = "claude-sonnet-4-6") -> Dict:
    """Returns {"summary": str, "mode": "llm"|"rule_based", "error": str|None}"""
    findings_summary = {cat: len(items) for cat, items in findings.items()}
    api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")

    if api_key:
        try:
            context_block = _build_context_block(findings_summary, risk_result, doc_stats)
            text = _call_claude(api_key, model, context_block)
            return {"summary": text, "mode": "llm", "error": None}
        except Exception as e:
            fallback = _rule_based_summary(findings_summary, risk_result, doc_stats)
            return {"summary": fallback, "mode": "rule_based",
                    "error": f"LLM call failed, used rule-based fallback: {e}"}

    fallback = _rule_based_summary(findings_summary, risk_result, doc_stats)
    return {"summary": fallback, "mode": "rule_based", "error": None}
