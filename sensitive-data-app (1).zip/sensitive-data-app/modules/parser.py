"""
parser.py
---------
Extracts raw text from uploaded PDF / TXT / CSV files so the rest of
the pipeline (detectors, risk scoring, summary, QA) can work on a
single plain-text representation regardless of source format.
"""

import io
import csv
from typing import Tuple

import pandas as pd


def parse_txt(file_bytes: bytes) -> str:
    for encoding in ("utf-8", "latin-1"):
        try:
            return file_bytes.decode(encoding)
        except UnicodeDecodeError:
            continue
    return file_bytes.decode("utf-8", errors="ignore")


def parse_csv(file_bytes: bytes) -> Tuple[str, "pd.DataFrame"]:
    """Returns (flattened_text, dataframe) so the UI can also render a table."""
    buffer = io.BytesIO(file_bytes)
    try:
        df = pd.read_csv(buffer)
    except Exception:
        buffer.seek(0)
        df = pd.read_csv(buffer, sep=None, engine="python")

    # Flatten to text: header row + each row's cells space-joined,
    # so regex detectors can scan every cell value.
    lines = [", ".join(str(c) for c in df.columns)]
    for _, row in df.iterrows():
        lines.append(", ".join(str(v) for v in row.values))
    return "\n".join(lines), df


def parse_pdf(file_bytes: bytes) -> str:
    """Extract text from a PDF using pypdf. Falls back gracefully on scanned PDFs
    (no OCR is bundled by default; a warning string is returned instead of raising)."""
    try:
        from pypdf import PdfReader
    except ImportError:
        from PyPDF2 import PdfReader  # type: ignore

    reader = PdfReader(io.BytesIO(file_bytes))
    pages_text = []
    for page in reader.pages:
        try:
            pages_text.append(page.extract_text() or "")
        except Exception:
            pages_text.append("")
    text = "\n".join(pages_text).strip()

    if not text:
        text = (
            "[No extractable text found. This PDF may be a scanned image. "
            "Enable OCR support (see README) to process scanned documents.]"
        )
    return text


def parse_document(filename: str, file_bytes: bytes):
    """
    Dispatch by extension.
    Returns (text, dataframe_or_none)
    """
    lower = filename.lower()
    if lower.endswith(".pdf"):
        return parse_pdf(file_bytes), None
    elif lower.endswith(".csv"):
        text, df = parse_csv(file_bytes)
        return text, df
    elif lower.endswith(".txt"):
        return parse_txt(file_bytes), None
    else:
        raise ValueError(f"Unsupported file type: {filename}")
