"""
audit.py
--------
Minimal audit trail: logs each document scan (filename hash, timestamp,
risk level, category counts - never raw sensitive values) to a local
JSONL file so usage/compliance activity can be reviewed later.
"""

import json
import hashlib
import os
from datetime import datetime, timezone

LOG_PATH = os.path.join(os.path.dirname(__file__), "..", "audit_log.jsonl")


def _hash_name(filename: str) -> str:
    return hashlib.sha256(filename.encode("utf-8")).hexdigest()[:16]


def log_scan(filename: str, risk_result: dict, findings_summary: dict):
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "file_id": _hash_name(filename + str(datetime.now().timestamp())),
        "filename_hash": _hash_name(filename),
        "risk_level": risk_result.get("risk_level"),
        "risk_score": risk_result.get("total_score"),
        "category_counts": findings_summary,
    }
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass  # audit logging must never break the main app
    return entry


def read_log(limit: int = 50):
    if not os.path.exists(LOG_PATH):
        return []
    with open(LOG_PATH, "r", encoding="utf-8") as f:
        lines = f.readlines()[-limit:]
    return [json.loads(l) for l in lines if l.strip()]
