# 🛡️ Sensitive Data Detection & Compliance Assistant

A Streamlit application that scans uploaded documents (PDF / TXT / CSV), detects
sensitive/confidential information, classifies the document's risk level, generates
an AI-assisted compliance & security summary, and lets you ask questions about the
document in natural language.

> Built as a self-contained, mostly offline-first tool: every detection, risk score,
> and structured Q&A answer works **without any API key**. An optional Anthropic API
> key unlocks a richer narrative summary and free-form Q&A on top of the same
> detector output.

---

## Demo

- **GitHub Repo:** `<add your repo URL here>`
- **Demo Video (2–5 min):** `<add your video URL here>`
- **Live Deployment:** `<add your Streamlit Community Cloud / other deployment URL here>`

---

## 1. Features

| Requirement | Status |
|---|---|
| Upload PDF / TXT / CSV | ✅ |
| Detect Aadhaar, PAN, Email, Phone, Credit Card, Bank Details, API Keys/Passwords, Employee IDs, Confidential markers | ✅ |
| Risk classification: Low / Medium / High | ✅ |
| AI-generated compliance summary (observations, security risks, remediation) | ✅ (LLM mode + offline rule-based fallback) |
| Chat-based Q&A over the document | ✅ (structured intents + LLM free-form fallback) |
| Data masking / redaction | ✅ (bonus) |
| Audit logging | ✅ (bonus) |
| Dockerization | ✅ (bonus) |
| Multi-document support | ⚠️ Partial — one document at a time in this version; see Future Improvements |
| OCR support | ❌ Not bundled by default; hook documented below |
| RAG (vector DB) | ⚠️ Lightweight keyword-chunking used instead of FAISS/Chroma — sufficient at document scale used here; documented as a future improvement |

---

## 2. Setup Instructions

### Prerequisites
- Python 3.10+
- (Optional) An [Anthropic API key](https://console.anthropic.com/) for AI-generated
  summaries and free-form Q&A

### Local setup

```bash
git clone <your-repo-url>
cd sensitive-data-app

python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

pip install -r requirements.txt

# Optional: enable AI summary / free-form Q&A
cp .env.example .env
# edit .env and add ANTHROPIC_API_KEY=sk-ant-...
export ANTHROPIC_API_KEY=sk-ant-...   # or paste it into the sidebar at runtime

streamlit run app.py
```

The app opens at `http://localhost:8501`. Try it immediately with the bundled
synthetic sample at `sample_data/sample.txt` (fake data only — safe to use).

### Docker

```bash
docker build -t sensitive-data-app .
docker run -p 8501:8501 -e ANTHROPIC_API_KEY=sk-ant-... sensitive-data-app
```

### Deploying (e.g. Streamlit Community Cloud)
1. Push this repo to GitHub.
2. On [share.streamlit.io](https://share.streamlit.io), create a new app pointing at
   `app.py`.
3. Add `ANTHROPIC_API_KEY` under **Settings → Secrets** (optional — the app runs
   without it).

---

## 3. Architecture Overview

```
┌────────────┐     ┌───────────────┐     ┌───────────────┐     ┌───────────────┐
│  Streamlit  │────▶│ modules/parser│────▶│modules/detectors│──▶│ modules/risk  │
│   app.py    │     │ (PDF/TXT/CSV) │     │  (regex+heuristics)│  │ (scoring)     │
└─────┬──────┘     └───────────────┘     └───────────────┘     └──────┬────────┘
      │                                                                 │
      │                                                                 ▼
      │                                                       ┌──────────────────┐
      │                                                       │modules/summarizer │
      │                                                       │ (LLM / rule-based)│
      │                                                       └──────────────────┘
      │
      │        ┌────────────────┐        ┌────────────────┐
      ├───────▶│ modules/masking │       │ modules/qa      │
      │        │ (redaction)     │       │ (intent match + │
      │        └────────────────┘        │  LLM RAG-lite)  │
      │                                   └────────────────┘
      │
      └───────▶ modules/audit (JSONL scan log — counts only, never raw values)
```

**Data flow for a single scan:**
1. `parser.py` converts the uploaded file into plain text (+ a DataFrame for CSVs).
2. `detectors.py` runs a battery of regex/heuristic detectors over the text and
   returns findings grouped by category, each with position, matched value, and a
   confidence tag.
3. `risk.py` converts findings into a transparent, auditable score: each category
   has a severity weight, counts are aggregated with diminishing returns (so 50
   emails don't outweigh one leaked Aadhaar number), and a small set of critical
   categories (Aadhaar, credit card, API keys, passwords) force at least a **High**
   classification even on a single occurrence.
4. `summarizer.py` builds the compliance narrative. If an API key is present, only
   **aggregated category counts and the risk score** — never the raw sensitive
   values — are sent to Claude, which writes the "Compliance Observations / Security
   Risks / Remediation Steps" sections. Without a key, the same three sections are
   built from templates driven by the same risk breakdown, so the app is fully
   usable offline.
5. `masking.py` produces a redacted copy of the document (e.g. `ab***@domain.com`,
   `****6467` for cards) for safe sharing/download.
6. `qa.py` answers document questions. Common intents ("how many X", "what sensitive
   data exists", "what compliance risks", "summarize") are matched and answered
   deterministically from the same findings/risk objects — no LLM call, no network
   trip, no data leaves the machine. Anything else falls back to Claude with the
   (optionally redacted) document text as context; for long documents, a lightweight
   keyword-overlap chunk selector keeps the context within budget instead of sending
   the entire file (a minimal, dependency-free "RAG-lite").
7. `audit.py` appends a JSONL record of each scan (hashed filename, timestamp, risk
   level, category **counts** — no raw sensitive values) for later compliance
   review.

### Why regex/heuristics instead of a trained NER model?
Categories like Aadhaar, PAN, IFSC, credit cards, and API keys have **highly
structured formats** that regex + checksum validation (e.g. Luhn for card numbers)
detects reliably and deterministically, with zero inference cost, full explainability
(you can point to exactly which pattern matched), and no model download/hosting.
This is the same approach production DLP tools (e.g. Microsoft Purview, AWS Macie)
use for structured PII. Where structure alone is ambiguous (bank account numbers are
just long digit runs), a nearby-keyword heuristic (e.g. "account no", "IFSC") is used
to cut false positives.

---

## 4. AI/ML Approach Used

- **Detection layer:** deterministic regex + light validation (Luhn checksum for
  card numbers, format rules for Aadhaar/PAN, keyword-proximity heuristics for bank
  accounts and confidential markers). No ML model is required for this stage —
  intentionally, for speed, explainability, and to avoid any inference cost or
  external dependency on the core compliance-critical function of the app.
- **Risk scoring:** transparent, rule-based weighted scoring (see `modules/risk.py`)
  rather than a black-box classifier, so every score is auditable — you can always
  answer "why did this get classified High?"
- **Generative layer (optional, via Anthropic's Claude API):**
  - *Compliance summary*: Claude receives only aggregated, anonymized statistics
    (category names + counts + computed risk score) and writes the natural-language
    compliance narrative. This is a deliberate privacy-by-design choice — the raw
    sensitive values never need to leave the machine for the summary to be useful.
  - *Free-form Q&A*: acts as a minimal single-document RAG — structured questions are
    answered directly from the detector/risk objects (no LLM); open-ended questions
    are answered by Claude grounded in the (optionally redacted) document text, with
    a keyword-overlap chunk selector standing in for a vector store at this
    document scale.
- **Fallback design:** every AI-assisted feature has a fully deterministic,
  offline fallback, so grading/demoing the app doesn't require an API key at all.

---

## 5. Challenges Faced

- **Balancing recall vs. false positives for loosely-structured categories.**
  Bank account numbers are just long digit strings — flagging every 9–18 digit
  number in a document would swamp the results with false positives (e.g. dates,
  invoice numbers). Solved with a keyword-proximity heuristic and de-duplication
  against overlapping spans already claimed by card/Aadhaar/phone detectors.
- **Aadhaar detection without a checksum library.** Aadhaar has a Verhoeff checksum
  digit, but implementing/validating it reliably without a reference dataset risked
  rejecting legitimate matches; the app uses format-only validation and labels these
  matches "medium confidence" rather than pretending to full certainty.
- **Avoiding leaking sensitive data to the LLM.** For the compliance summary, the
  design constraint was that raw values should never need to leave the environment.
  This shaped the summarizer to work purely off aggregated counts, and the Q&A
  redaction toggle to default to on for the LLM path.
- **Keeping the app fully functional without any external API.** Since evaluators
  may not want to provision an API key, every feature needed a deterministic
  fallback path, which doubled the design surface of the summary and QA modules but
  makes the tool practically useful as an offline DLP scanner too.
- **Scanned/image PDFs.** Text extraction naturally fails on scanned documents;
  rather than silently returning nothing, the parser returns an explicit "no
  extractable text — OCR needed" message so the risk isn't understated.

---

## 6. Future Improvements

- **OCR support** for scanned PDFs/images (e.g. `pytesseract` + `pdf2image`), so
  photographed or scanned documents can be scanned too.
- **True vector-store RAG** (FAISS/Chroma) for multi-document, cross-document Q&A
  at scale, replacing the current keyword-overlap chunk selector.
- **Multi-document / batch mode**, with a portfolio-level risk dashboard across an
  uploaded folder or connected storage bucket.
- **Aadhaar Verhoeff checksum validation** to raise detection confidence from
  "format match" to "verified valid number."
- **Named-entity augmentation** (e.g. spaCy NER) to catch unstructured PII like
  full names and addresses that pure regex can't reliably identify.
- **Role-based access & encrypted storage** for the audit log and any persisted
  redacted/original documents, plus configurable data-retention policies.
- **Exportable compliance report** (PDF/DOCX) combining the summary, findings table,
  and audit trail for formal review packets.
- **Configurable rule packs** per jurisdiction (e.g. GDPR/EU vs. DPDP/India vs.
  HIPAA/US) so the same engine can be tuned to different regulatory contexts.

---

## 7. Project Structure

```
sensitive-data-app/
├── app.py                     # Streamlit UI
├── modules/
│   ├── parser.py               # PDF/TXT/CSV → plain text
│   ├── detectors.py            # regex/heuristic sensitive-data detection
│   ├── risk.py                 # weighted risk scoring + Low/Medium/High
│   ├── summarizer.py           # AI + rule-based compliance summary
│   ├── qa.py                   # structured + LLM free-form Q&A
│   ├── masking.py              # redaction/masking
│   └── audit.py                # scan audit log (JSONL)
├── sample_data/
│   └── sample.txt              # synthetic demo document (fake data only)
├── requirements.txt
├── Dockerfile
├── .env.example
└── README.md
```

---

## 8. Security & Compliance Notes

- All detection and risk scoring run **locally**, no network call required.
- The optional LLM summary step sends **aggregated counts only**, never raw
  sensitive values.
- The optional LLM Q&A step defaults to sending the **redacted** document text.
- The audit log stores hashed filenames and category **counts** only — never raw
  sensitive values — so the log itself is safe to retain and review.
- This tool is a decision-support aid, not a certified DPO/legal compliance
  guarantee. High-risk findings should always be reviewed by a human before action
  is taken.
